// content.js
//alert("Hello from Inspirational Quotes Extension!")

async function getQuote() {
    let url = 'https://zenquotes.io/api/random';
    try {
        let res = await fetch(url);
        return await res.json();
    } catch (error) {
        console.log(error);
    }
}

async function renderQuote() {
    let quotes = await getQuote();

    let html = '';
    quotes.map(quote => {
        let htmlSegment = `<div>
                            ${quote.q}<br> 
							- ${quote.a}
                        </div>`;

        html += htmlSegment;
    });

    let container = document.querySelector('#quoteContainer');
    container.innerHTML = html;
}

renderQuote();

