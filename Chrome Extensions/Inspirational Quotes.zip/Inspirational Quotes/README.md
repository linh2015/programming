TABLE OF CONTENTS
-----------------
* Introduction
* Features
* Requirements
* Installation


INTRODUCTION
-----------------
Inspirational Quotes is a Chrome extension that displays a quote from infuential
figures throughout history each time the icon is clicked. We hope you start your
day off with positivity and timeless wisdom.


FEATURES
-----------------
Once installed, users can enjoy an inspirational quote each time they click on the
Inspirational Quotes icon.

Note:

Inspirational Quotes uses a Free licensed API from ZenQuotes so there is a
limited number of quotes that can be retreived in a day.

Background Photo Credit:

Russell Discommode


REQUIREMENTS
-----------------
- Chrome browser version 87.0.4280.88 +
- Winzip or similar application


INSTALLATION
-----------------
- Download the zip file from github:
     https://github.com/linh2015/programming/tree/main/Chrome%20Extensions
- Launch Chrome browser > Click on the Chrome browser icon in the upper right corner >
- Click on Manage extensions > Click on Developer mode > Click on Load unpacked >
- Click on the Chrome browser icon in the upper right corner >
- Click on the Inspirational Quotes